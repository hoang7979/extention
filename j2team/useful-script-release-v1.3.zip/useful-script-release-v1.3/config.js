export default {
  version_check:
    "https://raw.githubusercontent.com/HoangTran0410/useful-script/main/manifest.json",
  source_code: "https://github.com/HoangTran0410/useful-script",
};
