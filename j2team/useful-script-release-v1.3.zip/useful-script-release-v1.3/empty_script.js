export default {
  icon: "",
  name: {
    en: "",
    vi: "",
  },
  description: {
    en: "",
    vi: "",
  },

  // Chọn 1 trong 2 cách, xoá cách không dùng:

  // Cách 1: Mở link web trong tab mới, không cần dùng func
  link: "",

  // Cách 2: Chạy script
  blackList: [],
  whiteList: [],
  runInExtensionContext: false,
  func: function () {},
};
